<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class transaction extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     *
     * DB::table('transaction')->insert([
            'id' => 1,
            'nameProduct' => 'GForce NS70',
            'price' => 800000,
        ]);
     *
     */
    public function run()
    {


    }
}
