<?php $__env->startSection('content'); ?>

<div class="stock-list">
    <table class="table table-sm">
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Price</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($list->id); ?></td>
                <td><?php echo e($list->nameProduct); ?></td>
                <td><?php echo e($list->price); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="product-input">
    <form action="<?php echo e(route('transactiondetail')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="col-md-6 offset-md-4">
            <label for="ID Product">ID Product</label>
            <input type="number" id="product_id" name="product_id"  <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('product_id')); ?>">
            <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br> <br>
            <label for="quantity">Quantity</label>
            <input type="number" id="quantity" name="quantity" value="quantity">
            <br>
            <button type="submit" class="btn btn-primary">
                <?php echo e(__('Add')); ?>

            </button>
        </div>
    </form>
</div>
<br><br>
<div class="product-summary">
    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Sub Total</th>
            <th>Action</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($list->nameProduct); ?></td>
            <td><?php echo e($list->qty); ?></td>
            <td><?php echo e($list->price); ?></td>
            <td><?php echo e($list->subtotal); ?></td>
            <td>
                <form action="<?php echo e(route('transaction.delete', ['transaction_detail' => $list->product_id])); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No data
        <?php endif; ?>
    </table>
</div>
<br><br>
<div class="bayar primary">
    <button type="submit"  class="btn btn-primary">
        <a href="<?php echo e(route('viewTransaction')); ?>" style="text-decoration: none; color:white"> Payment </a>
    </button>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject\resources\views/home.blade.php ENDPATH**/ ?>