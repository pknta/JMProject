<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="stock-list">
        <table class="table table-md">
            <thead>
                <tr>
                    <th scope="col">Product ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Order Quantity</th>
                    <th scope="col">Action</th>
                    <th scope="col" class="text-end">Subtotal (Rp)</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($list->product_id); ?></th>
                        <td><?php echo e($list->nameProduct); ?></td>
                        <td><?php echo e(number_format($list->price, 0, ',', '.')); ?></td>
                        <td class="w-25">
                            <input type="number form-control" value="<?php echo e($list->qty); ?>" id="quantity" name="quantity" form="<?php echo e('update'.$list->product_id); ?>">
                        </td>
                        <td>
                            <button class="btn btn-primary" form="<?php echo e('update'.$list->product_id); ?>">Update</button>
                            <button class="btn btn-danger" form="<?php echo e('delete'.$list->product_id); ?>">Delete</button>
                        </td>
                        <td class="text-end"><?php echo e(number_format($list->price * $list->qty, 0, ',', '.')); ?></td>
                    </tr>
                    <form method="POST" action="<?php echo e(route('transaction.update', ['prodid'=>$list->product_id])); ?>" id="<?php echo e('update'.$list->product_id); ?>">
                        <?php echo csrf_field(); ?>
                    </form>
                    <form method="POST" action="<?php echo e(route('transaction.delete', ['transaction_detail'=>$list->product_id])); ?>" id="<?php echo e('delete'.$list->product_id); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="2">
                        <select class="form-control" id="id" name="id" form="add_form">
                            <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($prod->id); ?>"> <?php echo e($prod->id); ?> | <?php echo e($prod->nameProduct); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td></td>
                    <td>
                        <input type="number form-control" value="1" id="quantity" name="quantity" form="add_form">
                    </td>
                    <td>
                        <button class="btn btn-success" form="add_form"> Add </button>
                    </td>
                    <td></td>
                    <form method="POST" action="<?php echo e(route('transaction.add')); ?>" id="add_form">
                        <?php echo csrf_field(); ?>
                    </form>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="container bg-dark text-light d-flex justify-content-between rounded p-3">
        <h3>
            Total : <?php echo e(number_format($total, 0, ',', '.')); ?>

        </h3>
        <a class="btn btn-light text-dark" href="<?php echo e(route('viewTransaction')); ?>"> Payment </a>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject_edited\resources\views/home.blade.php ENDPATH**/ ?>