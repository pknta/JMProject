<?php $__env->startSection('content'); ?>
<div>
    Transaction ID : <?php echo e($transID); ?>

</div>
<div class="d-flex justify-content-end">
    <div>
        Staff Name : <?php echo e(Auth::user()->name); ?>

    </div>
</div>
<br><br>
<div class="product-summary d-flex justify-content-center">
    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Sub Total</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($list->nameProduct); ?></td>
            <td><?php echo e($list->qty); ?></td>
            <td><?php echo e($list->price); ?></td>
            <td><?php echo e($list->subtotal); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>
<div class="position-relative col-md-6">
    <h4>Total Price : <?php echo e($totalPrice); ?> </h4>
    <form action="<?php echo e(route('kembalian')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="diterima">Total Pay</label>
        <input type="number" class="form-control" value="diterima" name="diterima" id="diterima">
        <button type="submit"  class="btn btn-primary">Pay</button>
    </form>
</div>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject\resources\views/transaction.blade.php ENDPATH**/ ?>