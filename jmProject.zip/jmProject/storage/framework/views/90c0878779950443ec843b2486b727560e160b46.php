<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row d-flex justify-content-between">
        <div class="col-sm-6">
            <div class="card rounded col-sm-12 px-0 sticky-top" style="top: 30px">
                <div class="card-body text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill my-3" viewBox="0 0 16 16" style="color: green; height: 5em !important; width:auto !important;">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                    </svg>
                    <h4 class="card-title mb-5"> Payment Completed </h4>
                    <a href="<?php echo e(route('stocklist')); ?>" class="btn btn-success form-control mb-3"> New Transaction </a>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            <div class="card rounded col-sm-12 p-0">
                <div class="card-header">
                    Payment Details
                </div>
                <div class="card-body">
                    <table class="table table-md table-borderless">
                        <tbody>
                            <tr>
                                <th> Transaction #<?php echo e($transaction->id); ?> </th>
                                <th class="text-end"> Staff: <?php echo e(Auth::user()->name); ?> </th>
                            </tr>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($list->nameProduct); ?> (<?php echo e($list->qty); ?>x)</th>
                                    <td class="text-end"><?php echo e(number_format($list->price * $list->qty, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-top:1px solid !important;">
                                <th style="font-size:1.25em">Total</th>
                                <th class="text-end" style="font-size: 1.25em"><?php echo e(number_format($totalPrice, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Paid</th>
                                <th class="text-end"><?php echo e(number_format($transaction->pay, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Change</th>
                                <th class="text-end" style="border-top:1px solid !important;"><?php echo e(number_format($transaction->pay - $totalPrice, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Paid at</th>
                                <td class="text-end"><?php echo e($transaction->date); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jmProject\resources\views/transactionend.blade.php ENDPATH**/ ?>