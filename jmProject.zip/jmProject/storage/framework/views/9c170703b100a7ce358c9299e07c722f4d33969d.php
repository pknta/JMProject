<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center">
    <h1>KEMBALIAN</h1>
</div>

<div>
    <h1>Rp <?php echo e($change); ?> </h1>
</div>

<div class="bayar primary">
    <button type="submit"  class="btn btn-primary">
        <a href="<?php echo e(route('stocklist')); ?>" style="text-decoration: none; color:white"> Back </a>
    </button>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject\resources\views/transactionend.blade.php ENDPATH**/ ?>