<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 d-flex justify-content-between">

            <div class="user-profile">
                <p>Admin Name : <?php echo e(Auth::user()->name); ?></p>
                <p>Admin Email : <?php echo e(Auth::user()->email); ?></p>
                <p>Admin Age : <?php echo e(Auth::user()->usia); ?></p>
                <p>Admin Shift : <?php echo e(Auth::user()->shift); ?></p>
            </div>

                

                <div class="picture">

                    <?php if(Auth::user()->image): ?>
                    <img class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 200px;height: 200px; padding: 10px; margin: 0px; ">
                    <?php endif; ?>

                    <div class="card-body">
                        <form action="<?php echo e(route('editprofile')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="image">
                            <input type="submit" value="Upload">
                        </form>
                    </div>
                </div>

        </div>
        </div>
        
        <div class="row mb-0 justify-content-center">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    <a href="<?php echo e(url('/home')); ?>" style="text-decoration:none; color:white">
                        <?php echo e(__('Back')); ?>

                    </a>
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jmProject\resources\views/editprofile.blade.php ENDPATH**/ ?>