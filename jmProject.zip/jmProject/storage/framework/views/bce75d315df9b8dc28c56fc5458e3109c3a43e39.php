

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="container text-center">
        <h2> Transaction History </h2>
        <?php if(empty($staff)): ?>
            <h5> Staff: <?php echo e(Auth::user()->name); ?> </h5>
        <?php else: ?>
            <h5> Staff: <?php echo e($staff->name); ?> </h5>
        <?php endif; ?>
    </div>

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 my-2">
                <div class="card rounded col-sm-12 p-0">
                    <div class="card-header" data-bs-toggle="collapse" href="<?php echo e('#collapse'.$transaction->id); ?>" role="button">
                        <p class="card-text">
                            Transaction #<?php echo e($transaction->id); ?>

                            <br>
                            Paid at <?php echo e($transaction->date); ?>

                        </p>
                    </div>
                    <div class="collapse" id="<?php echo e('collapse'.$transaction->id); ?>">
                        <div class="card-body">
                            <table class="table table-md table-borderless">
                                <tbody>
                                    <?php $totalPrice = 0 ?>
                                    <?php $__currentLoopData = $transaction->transactionDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($detail->stocks->nameProduct); ?> (<?php echo e($detail->qty); ?>x)</th>
                                            <td class="text-end"><?php echo e(number_format($detail->stocks->price * $detail->qty, 0, ',', '.')); ?></td>
                                        </tr>
                                        <?php $totalPrice += $detail->stocks->price * $detail->qty ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr style="border-top:1px solid !important;">
                                        <th style="font-size:1.25em">Total</th>
                                        <th class="text-end" style="font-size: 1.25em"><?php echo e(number_format($totalPrice, 0, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Paid</th>
                                        <th class="text-end"><?php echo e(number_format($transaction->pay, 0, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Change</th>
                                        <th class="text-end" style="border-top:1px solid !important;"><?php echo e(number_format($transaction->pay - $totalPrice, 0, ',', '.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div> 
                </div>
            </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject_edited\resources\views/transaction_history.blade.php ENDPATH**/ ?>