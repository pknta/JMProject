<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row d-flex justify-content-between">
        <div class="col-sm-6">
            <div class="card rounded col-sm-12 px-0 sticky-top" style="top: 30px">
                <div class="card-header">
                    Payment Details
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('kembalian')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-sm-6">
                                <label for="transaction_id"> Transaction ID </label>
                                <fieldset disabled>
                                    <input type="text" id="transaction_id" name="transaction_id" class="form-control" placeholder="<?php echo e($transaction->id); ?>">
                                </fieldset>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="staff_name"> Staff Name</label>
                                <fieldset disabled>
                                    <input type="text" id="staff_name" name="staff_name" class="form-control" placeholder="<?php echo e(Auth::user()->name); ?>">
                                </fieldset>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="payment"> Payment Received </label>
                            <input type="number" id="payment" name="payment" class="form-control" placeholder="<?php echo e($totalPrice); ?>" value="<?php echo e($totalPrice); ?>">
                        </div>
                        <div class="form-group">
                            <label for="date"> Checkout Date </label>
                            <input type="date" id="date" name="date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary form-control"> Complete Payment </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            <div class="card rounded col-sm-12 p-0">
                <div class="card-header">
                    Order Details
                </div>
                <div class="card-body">
                    <table class="table table-md table-borderless">
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($list->nameProduct); ?> (<?php echo e($list->qty); ?>x)</th>
                                    <td class="text-end"><?php echo e(number_format($list->price * $list->qty, 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-top:1px solid !important;">
                                <th style="font-size:1.25em">Total</th>
                                <th class="text-end" style="font-size: 1.25em"><?php echo e(number_format($totalPrice, 0, ',', '.')); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jmProject\resources\views/transaction.blade.php ENDPATH**/ ?>