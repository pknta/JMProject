

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="container text-center">
        <h2> Manage Users </h2>
    </div>

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 my-2">
                <div class="card rounded col-sm-12 p-0">
                    <div class="card-header">
                        <p class="card-text"> <?php echo e($user->id." | ".$user->name); ?> </p>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('user.history', ['staff_id'=>$user->id])); ?>" class="btn btn-primary form-control"> View Transaction History </a>
                        <form method="POST" action="<?php echo e(route('user.delete', ['user_id'=>$user->id])); ?>">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger form-control"> Delete </a>
                        </form>
                    </div>
                </div>
            </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\program\xampp\htdocs\jmProject_edited\resources\views/manageuser.blade.php ENDPATH**/ ?>